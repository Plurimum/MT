
rootProject.name = "lab2"

