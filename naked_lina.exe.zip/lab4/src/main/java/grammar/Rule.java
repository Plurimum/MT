package grammar;

public record Rule(RuleDeclaration decl, RuleBody body) {
}
