package grammar;

public record RuleDeclaration(String name, String inherited, String synthesized) {
}
