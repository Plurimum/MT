package grammar;

public record Element(String name, String inherited) {
}
