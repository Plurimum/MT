package grammar;

import java.util.List;

public record Sequence(List<Element> elements, String code) {
}
