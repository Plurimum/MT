package grammar;

public record Terminal(String name, String value) {
}
