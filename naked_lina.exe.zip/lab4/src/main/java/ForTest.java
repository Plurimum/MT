

public class ForTest {
    public static void main(String[] args) {
        /*String test = "for (int a = 2; b < 3; k++)";
        LexicalAnalyzer lexicalAnalyzer = new LexicalAnalyzer(test);
        Parser parser = new Parser(lexicalAnalyzer);
        System.out.println(parser.s().toString());*/
    }
}
