package generated.parser_for;

public class ParseException extends RuntimeException {
    public ParseException(String message) {
        super(message);
    }
}
